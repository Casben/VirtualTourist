//
//  PhotoAlbumVC.swift
//  VirtualTourist
//
//  Created by Herbert Dodge on 7/25/20.
//  Copyright © 2020 Herbert Dodge. All rights reserved.
//

import UIKit
import MapKit
import CoreData

class PhotoAlbumVC: UIViewController, NSFetchedResultsControllerDelegate {
    
    let mapView = MKMapView()
    let collectionView = UICollectionView(frame: .zero, collectionViewLayout: UICollectionViewFlowLayout())
    
    var passedInAnnotation: MKAnnotation!
    var passedInPin: Pin!
    
    var fetchedResultsController: NSFetchedResultsController<Photo>!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configure()
        downloadPhotoUrls()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        configure()
        downloadPhotoUrls()
    }
    
    
    //MARK: - Methods
    func configureResultsController(_ pin: Pin) {
        let fetchRequest: NSFetchRequest<Photo> = Photo.fetchRequest()
        let sortDescriptor = NSSortDescriptor(key: "name", ascending: false)
        fetchRequest.predicate = NSPredicate(format: "pin == %@", argumentArray: [pin])
        fetchRequest.sortDescriptors = [sortDescriptor]
        
        fetchedResultsController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: DataController.shared.viewContext, sectionNameKeyPath: nil, cacheName: nil)
        fetchedResultsController.delegate = self
        
        do {
            try fetchedResultsController.performFetch()
        } catch {
            print("error fetching data")
        }
    }
    
    func downloadPhotoUrls() {
        NetworkManager.shared.getPhotosAt(latitude: passedInPin.latitude, longitude: passedInPin.longitude) { (response, error) in
            if error != nil {
                print("unable to retrieve response data")
            }
            guard let response = response else { return }
            let photoUrls = NetworkManager.shared.constructPhotoUrl(response)
            
            for url in photoUrls {
                self.addPhoto(url: url.absoluteString)
                print(url.absoluteString)
            }
            DispatchQueue.main.async {
                self.collectionView.reloadData()
            }
        }
    }
    
    func addPhoto(url: String) {
        let photo = Photo(context: DataController.shared.viewContext)
        photo.name = url
        photo.pin = passedInPin
        try? DataController.shared.viewContext.save()
    }
    
    func configureImage(using cell: PhotoCell, photo: Photo, collectionView: UICollectionView, index: IndexPath) {
        if let image = photo.image {
            cell.activityIndicator.stopAnimating()
            cell.imageView.image = UIImage(data: image)
        } else {
            if let imageUrl = photo.name {
                cell.activityIndicator.startAnimating()
                guard let downloadUrl = URL(string: imageUrl) else { return }
                NetworkManager.shared.downloadImage(imageUrl: downloadUrl) { (data, error) in
                    if error != nil {
                        print("unable to download image")
                        return
                    }
                    guard let data = data else { return }
                    DispatchQueue.main.async {
                        if let currentCell = collectionView.cellForItem(at: index) as? PhotoCell {
                        if currentCell.imageUrl == imageUrl {
                            currentCell.imageView.image = UIImage(data: data)
                            cell.activityIndicator.stopAnimating()
                        }
                    }
                        photo.image = NSData(data: data) as Data
                        DispatchQueue.global(qos: .background).async {
                            try? DataController.shared.viewContext.save()
                        }
                    }
                }
            }
        }
    }
    
    //MARK: - Helpers
    
    @objc func dismissPhotoAlbum() {
        dismiss(animated: true)
    }
    
    
    //MARK: - Configuration
    func configure() {
        view.addSubviews(mapView, collectionView)
        view.backgroundColor = .white
        configureNavigationBar()
        configureCollectionView()
        configureMapView()
        configureResultsController(passedInPin)
        
        NSLayoutConstraint.activate([
            mapView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            mapView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            mapView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            mapView.heightAnchor.constraint(equalToConstant: 120),
            
            collectionView.topAnchor.constraint(equalTo: mapView.bottomAnchor),
            collectionView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            collectionView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            collectionView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor)
        ])
    }
    
    
    func configureNavigationBar() {
        let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(dismissPhotoAlbum))
        navigationItem.rightBarButtonItem = doneButton
        navigationController?.navigationBar.tintColor = .systemIndigo
    }
    
    func configureCollectionView() {
        collectionView.dataSource = self
        collectionView.delegate = self
        collectionView.register(PhotoCell.self, forCellWithReuseIdentifier: PhotoCell.reuseIdentifier)
        collectionView.backgroundColor = .systemGray2
        
    }
    
    func configureMapView() {
        mapView.delegate = self
        mapView.addAnnotation(passedInAnnotation)
        mapView.isScrollEnabled = false
        mapView.fitAll()
    }
}

//MARK: - MapView Delegate
extension PhotoAlbumVC: MKMapViewDelegate {
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        let reuseId = "pin"
        var pinView = mapView.dequeueReusableAnnotationView(withIdentifier: reuseId) as? MKPinAnnotationView

        if pinView == nil {
            pinView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: reuseId)
            pinView!.canShowCallout = true
            pinView!.animatesDrop = true
            pinView!.pinTintColor = .systemIndigo
            pinView!.rightCalloutAccessoryView = UIButton(type: .detailDisclosure)
        }
        else {
            pinView!.annotation = annotation
        }
        return pinView
    }
}

//MARK: - UICollectionView Delegate

extension PhotoAlbumVC: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return fetchedResultsController.sections?[section].numberOfObjects ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
//        let aPhoto = fetchedResultsController.object(at: indexPath)
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: PhotoCell.reuseIdentifier, for: indexPath) as! PhotoCell
        cell.imageView.image = nil
        cell.activityIndicator.startAnimating()
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        let photo = fetchedResultsController.object(at: indexPath)
        let photoViewCell = cell as! PhotoCell
        photoViewCell.imageUrl = photo.name!
        configureImage(using: photoViewCell, photo: photo, collectionView: collectionView, index: indexPath)
    }
}

extension PhotoAlbumVC: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 85, height: 75)
    }
}

