//
//  MapViewVC.swift
//  VirtualTourist
//
//  Created by Herbert Dodge on 7/25/20.
//  Copyright © 2020 Herbert Dodge. All rights reserved.
//

import UIKit
import MapKit

class MapViewVC: UIViewController {
    
    let mapView = MKMapView()
    let editHeaderView = UIView()
    let editLabel = CustomLabel(title: "Tap on a pin to delete.", fontSize: 22)
    var pinAnnotation: MKPointAnnotation? = nil

    override func viewDidLoad() {
        super.viewDidLoad()
        configure()
    }
    
    //MARK: - Helpers
    @objc func handleAddPinToMap(_ sender: UITapGestureRecognizer) {
        let location = sender.location(in: mapView)
        let locationCoordinates = mapView.convert(location, toCoordinateFrom: mapView)
        
        if sender.state == .began {
            pinAnnotation = MKPointAnnotation()
            pinAnnotation?.coordinate = locationCoordinates
            
            mapView.addAnnotation(pinAnnotation!)
        } else if sender.state == .changed {
            // come back to
        } else if sender.state == .ended {
            
            let pinToBeSaved = Pin(context: DataController.shared.viewContext)
            pinToBeSaved.latitude = pinAnnotation!.coordinate.latitude
            pinToBeSaved.longitude = pinAnnotation!.coordinate.longitude
            
            do {
                try DataController.shared.viewContext.save()
            } catch {
                print("Unable to save pin to context.")
            }
        }
        
        
        
        
        
        
        
        
        
        
        
        
        
        
//        if sender.state == .ended {
//            let point = sender.location(in: self.mapView)
//            let coordinate = self.mapView.convert(point, toCoordinateFrom: self.mapView)
//            let annotation = MKPointAnnotation()
//            annotation.coordinate = coordinate
//            annotation.title = ""
//            annotation.subtitle = ""
//            self.mapView.addAnnotation(annotation)
//        }
    }
    
    func configure() {
        configureMapView()
        configureNavigationBar()
        view.addSubviews(editHeaderView)
        editHeaderView.addSubviews(editLabel)
        
        NSLayoutConstraint.activate([
            editHeaderView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            editHeaderView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            editHeaderView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            editHeaderView.heightAnchor.constraint(equalToConstant: 50),
            
            editLabel.centerYAnchor.constraint(equalTo: editHeaderView.centerYAnchor),
            editLabel.centerXAnchor.constraint(equalTo: editHeaderView.centerXAnchor),
            editLabel.leadingAnchor.constraint(equalTo: editHeaderView.leadingAnchor),
            editLabel.trailingAnchor.constraint(equalTo: editHeaderView.trailingAnchor)
        ])
        
        editHeaderView.backgroundColor = .systemIndigo
        editHeaderView.isHidden = true
    }
    
    func configureNavigationBar() {
        navigationController?.navigationBar.tintColor = .systemIndigo
        navigationItem.rightBarButtonItem = editButtonItem
    }
    
    func configureMapView() {
        view = mapView
        mapView.delegate = self
        let longPressTap = UILongPressGestureRecognizer(target: self, action: #selector(handleAddPinToMap(_:)))
        mapView.addGestureRecognizer(longPressTap)
    }
    
    override func setEditing(_ editing: Bool, animated: Bool) {
        super.setEditing(editing, animated: animated)
        editHeaderView.isHidden = !editing
    }
    
}
//MARK: - MapView Delegate
extension MapViewVC: MKMapViewDelegate {
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        let reuseId = "pin"
        var pinView = mapView.dequeueReusableAnnotationView(withIdentifier: reuseId) as? MKPinAnnotationView

        if pinView == nil {
            pinView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: reuseId)
            pinView!.canShowCallout = true
            pinView!.pinTintColor = .systemIndigo
            pinView!.rightCalloutAccessoryView = UIButton(type: .detailDisclosure)
        }
        else {
            pinView!.annotation = annotation
        }
        return pinView
    }
    
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
        if control == view.rightCalloutAccessoryView {
            //present on main thread alert "no link defined"
        }
    }
    func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
        
        guard let annotation = view.annotation else {
            return
        }
        mapView.deselectAnnotation(annotation, animated: true)
        
        //here we will convert string from lat and long data then commit save to datacontroller
        
        let photoVC = PhotoAlbumVC()
        let destinationVC = UINavigationController(rootViewController: photoVC)
        destinationVC.modalPresentationStyle = .fullScreen
        present(destinationVC, animated: true)
    }
    
}
